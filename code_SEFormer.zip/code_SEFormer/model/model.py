import torch
from torch import nn
# from eth_ucy.gcl_t import GCL, E_GCL, E_GCL_vel, GCL_rf_vel, DynE_GCL_vel, DynE_GCL_vel_channel,DynE_GCL_vel_channel_clean
import numpy as np
from torch.nn import functional as F
from torch.nn.parameter import Parameter
import random
import math
import sys
print(sys.path)

import dctnet

class SEFormer(nn.Module):
    def __init__(self, 
                in_dim,
                h_dim, 
                past_timestep, 
                future_timestep, 
                mask_ratio, 
                decoder_dim=64, 
                num_heads=8, 
                encoder_depth=3, 
                decoder_depth=1,
                decoder_dim_per_head=32,
                same_head=True,
                range_mask_ratio=False,
                dim_per_head=64,
                mlp_head=False,
                mask_past=False,
                mask_range=20,
                multi_output=False,
                decoder_masking=False,
                pred_all=False,
                mlp_dim=64,
                use_projector=False,
                easier_given_dest=False,
                noise_dev=0.,
                part_noise=False,
                denoise_mode='all',
                part_noise_ratio=0.25,
                add_joint_token=False,
                n_agent=22,
                concat_vel=False,
                concat_acc=False,
                dropout=0.,
                only_recons_past=False,
                two_mask_mode=False,
                add_residual=False,
                denoise=True,
                regular_masking=False,
                multi_same_head=False,
                range_noise_dev=False,
                virtual_joint = True):
        super(SEFormer, self).__init__()
        self.n_agent = n_agent
        self.all_timesteps = past_timestep + future_timestep
        self.mask_ratio = mask_ratio
        self.dropout = dropout
        self.range_mask_ratio = range_mask_ratio
        self.pred_num_masked = future_timestep
        self.mask_embed = nn.Parameter(torch.randn(decoder_dim))
        self.past_timestep = past_timestep
        self.future_timestep = future_timestep
        self.mask_past = mask_past
        self.mask_range = mask_range
        self.multi_output = multi_output
        self.decoder_masking = decoder_masking
        self.encoder_depth = encoder_depth
        self.patch_embed = nn.Linear(in_dim, h_dim)
        self.decoder_pos_embed = nn.Embedding(self.all_timesteps, decoder_dim)
        self.decoder_agent_embed = nn.Embedding(n_agent*2-1, decoder_dim)
        # self.decoder_agent_embed = nn.Embedding(n_agent, decoder_dim)
        self.only_recons_past = only_recons_past

        self.pred_time = 1
        self.pred_all = pred_all
        self.concat_vel = concat_vel
        self.concat_acc = concat_acc
        if self.concat_vel:
            self.patch_embed = nn.Linear(6, h_dim)
        elif self.concat_acc:
            self.patch_embed = nn.Linear(9, h_dim)
        else:
            self.patch_embed = nn.Linear(3, h_dim)
        self.noise_dev = noise_dev
        self.part_noise = part_noise
        self.part_noise_ratio = part_noise_ratio
        self.denoise_mode = denoise_mode
        self.add_joint_token = add_joint_token
        self.mlp_head = mlp_head
        #self.agent_embed = nn.Parameter(torch.randn(1, n_agent, 1, h_dim))
        self.agent_embed = nn.Parameter(torch.randn(1, n_agent*2-1, 1, h_dim))
        
        # self.agent_embed = nn.Parameter(torch.empty(1, n_agent, 1, h_dim)).cuda()
        self.pos_embed = nn.Parameter(torch.randn(1, 1, self.all_timesteps, h_dim))
        self.two_mask_mode = two_mask_mode
        self.add_residual = add_residual
        self.regular_masking = regular_masking
        self.multi_same_head = multi_same_head      
        self.range_noise_dev = range_noise_dev
        self.virtual_joint = virtual_joint

        if self.multi_output:
            self.head = []
            for i in range(self.encoder_depth):
                if mlp_head:
                    self.head.append(MLP(decoder_dim, 3*self.pred_time,hidden_size=(128,)))
                else:
                    self.head.append(nn.Linear(decoder_dim, 3*self.pred_time))
            self.head = nn.ModuleList(self.head)
        else:
            if mlp_head:
                self.head = MLP(decoder_dim, 3*self.pred_time,hidden_size=(decoder_dim,))
            else:
                self.head = nn.Linear(decoder_dim, 3*self.pred_time)
        self.same_head = same_head
        if not same_head:
            if mlp_head:
                self.aux_head = MLP(decoder_dim, 3*self.pred_time,hidden_size=(decoder_dim,))
                # self.aux_head = MLP(decoder_dim, 2*self.pred_time,hidden_size=())
                self.aux_head_2 = MLP(decoder_dim, 3*self.pred_time,hidden_size=(decoder_dim,))
            else:
                self.aux_head = nn.Linear(decoder_dim, 3*self.pred_time)
                self.aux_head_2 = nn.Linear(decoder_dim, 3*self.pred_time)
        
        self.encoder = []
        self.decoder = []
        for _ in range(self.encoder_depth):
            self.encoder.append(STTrans(self.all_timesteps, h_dim, n_agent=self.n_agent,depth=1,mlp_dim=mlp_dim,num_heads=num_heads,dim_per_head=dim_per_head,dropout=dropout))
            self.decoder.append(STTrans(self.all_timesteps, h_dim, n_agent=self.n_agent,depth=1,mlp_dim=mlp_dim,num_heads=num_heads,dim_per_head=dim_per_head,dropout=dropout))
        self.encoder = nn.ModuleList(self.encoder)
        self.decoder = nn.ModuleList(self.decoder)

    def forward(self,all_traj):
        if self.virtual_joint:
            all_traj = self.get_padding_traj(all_traj)
            all_traj_virtual = all_traj.clone()
        B,N,T = all_traj.shape[0],all_traj.shape[1],all_traj.shape[2]

        all_traj = all_traj.view(B,N,T,3)
        start = all_traj[:,:,self.past_timestep-1:self.past_timestep] #12 25 1 3

        batch_ind = torch.arange(B)[:,None,None].cuda() #torch.Size([12, 1, 1])
        agent_ind = torch.arange(N)[None,:,None].cuda() #torch.Size([1, 25, 1])

        ordinary_mask = torch.zeros((B,N,T)).type_as(all_traj)
        ordinary_mask[:,:,:self.past_timestep] = 1.

        mask_ratio = self.mask_ratio
        if self.range_mask_ratio:
            mask_ratio = random.choice([0.3,0.4,0.5,0.6,0.7])
        
        if self.range_noise_dev:
            noise_dev = np.random.uniform(low=0.1, high=1.0)
        else:
            noise_dev = self.noise_dev

        if self.regular_masking:
            mask = torch.ones((B,N,self.past_timestep)).type_as(all_traj)
            shuffle_indices = torch.rand((B,N,self.past_timestep)).argsort().cuda()
            mask_indices = shuffle_indices[:,:,:int(self.past_timestep*mask_ratio)]
            mask[batch_ind,agent_ind,mask_indices] = 0
            assert torch.sum(mask) == (self.past_timestep-int(self.past_timestep*mask_ratio))*B*N
            mask = mask.view(B,N,-1)
            future_mask = torch.zeros((B,N,self.future_timestep)).type_as(all_traj)
            mask_with_no_future = torch.cat([mask,torch.ones_like(future_mask)],dim=-1)
            mask = torch.cat([mask,future_mask],dim=-1)

        else:
            mask = torch.ones((B,N*self.past_timestep)).type_as(all_traj)
            shuffle_indices = torch.rand((B,N*self.past_timestep)).argsort().cuda()
            mask_indices = shuffle_indices[:,:int(N*self.past_timestep*mask_ratio)]
            batch_ind2 = torch.arange(B)[:,None].cuda()
            mask[batch_ind2,mask_indices] = 0
            assert torch.sum(mask) == (N*self.past_timestep-int(N*self.past_timestep*mask_ratio))*B
            mask = mask.view(B,N,-1)
            future_mask = torch.zeros((B,N,self.future_timestep)).type_as(all_traj)
            mask_with_no_future = torch.cat([mask,torch.ones_like(future_mask)],dim=-1)
            mask = torch.cat([mask,future_mask],dim=-1)

        denoise_mask = torch.zeros((B,N,T)).type_as(all_traj)
        denoise_mask[:,:,:self.past_timestep] = 1.
        noise = torch.from_numpy(np.random.normal(loc=0., scale=noise_dev, size=(B,N,T,3))).type_as(all_traj)
        if self.part_noise:
            noise_mask = torch.rand(B,N,T).cuda()
            noise_mask = (noise_mask < self.part_noise_ratio).type_as(all_traj)
            noise = noise * noise_mask[:,:,:,None].repeat(1,1,1,3)
        all_traj_noise = all_traj + noise

        if self.multi_output:
            out = self.mask_forward(all_traj,ordinary_mask,all_out=True)
        else:
            decoded_tokens = self.mask_forward(all_traj,ordinary_mask)#12 25 20 64
            

        decoded_tokens_aux = self.mask_forward(all_traj,mask) #12 25 20 64
        decoded_tokens_noise = self.mask_forward(all_traj_noise,denoise_mask)#12 25 20 64


        past_future_indices = torch.arange(T)[None].repeat(B,1).cuda() #torch.Size([12, 20])
        past_future_indices = past_future_indices[:,None,:].repeat(1,N,1) # torch.Size([12, 25,20])
        past_ind, future_ind = past_future_indices[:,:, :self.past_timestep], past_future_indices[:,:, self.past_timestep:] #torch.Size([12, 25, 10])

        if self.multi_output:
            pred_future_coord_values = []
            for ind in range(len(out)):
                if self.multi_same_head:
                    head_ind = -1
                else:
                    head_ind = ind
                if self.mlp_head:
                    output = self.head[head_ind](out[ind][batch_ind,agent_ind, future_ind, :])
                else:
                    output = self.head[head_ind](out[ind][batch_ind,agent_ind, future_ind, :])
               
                output = output.view(B,N,-1,3)
                if self.add_residual:
                    output += start
                pred_future_coord_values.append(output)
        else:
            dec_future_tokens = decoded_tokens[batch_ind,agent_ind, future_ind, :] #12 25 10 64
            #dec_future_tokens = self.sample_to_original_size(dec_future_tokens)
            B,N,T,_ = dec_future_tokens.shape
            pred_future_coord_values = self.head(dec_future_tokens) # 12 25 10 3
            pred_future_coord_values = pred_future_coord_values.view(B,N,-1,3) #12 25 10 3
            if self.add_residual:
                #start = self.sample_to_original_size(dec_future_tokens)
                pred_future_coord_values += start 

        if self.virtual_joint:
            pred_future_coord_values_virtual = self.head(decoded_tokens)
            pred_future_coord_values_virtual = pred_future_coord_values_virtual.view(B,decoded_tokens.shape[1],-1,3)
            if self.add_residual:
                pred_future_coord_values_virtual += start 

        #pred_future_coord_values_virtual = self.sample_to_virtual(pred_future_coord_values_virtual)

        dec_mask_tokens = decoded_tokens_aux
        #dec_mask_tokens = self.sample_to_original_size(dec_mask_tokens)

        if self.same_head:
            if self.multi_output:
                pred_mask_coord_values = self.head[-1](dec_mask_tokens)
            else:
                pred_mask_coord_values = self.head(dec_mask_tokens)
        else:
            pred_mask_coord_values = self.aux_head(dec_mask_tokens) #12 25 10 3

        pred_mask_coord_values = pred_mask_coord_values.view(B,N,-1,3) #torch.Size([12, 25, 20, 3])

        if self.add_residual:
            pred_mask_coord_values += start

        if self.pred_all:
            pred_mask_coord_values = pred_mask_coord_values
            masked_gt = all_traj
        elif self.only_recons_past:
            pred_mask_coord_values = pred_mask_coord_values * (1 - mask_with_no_future[:,:,:,None])
            masked_gt = all_traj * (1 - mask_with_no_future[:,:,:,None])
        else:
            pred_mask_coord_values = pred_mask_coord_values * (1 - mask[:,:,:,None]) 
            masked_gt = all_traj * (1 - mask[:,:,:,None])


        if self.denoise_mode == 'all':
            dec_mask_tokens_noise = decoded_tokens_noise
        elif self.denoise_mode == 'past':

            dec_mask_tokens_noise = decoded_tokens_noise[batch_ind,agent_ind, past_ind, :]
        elif self.denoise_mode == 'future':
            dec_mask_tokens_noise = decoded_tokens_noise[batch_ind,agent_ind, future_ind, :]

        if self.same_head:
            if self.multi_output:
                pred_mask_coord_values_noise = self.head[-1](dec_mask_tokens_noise)
            else:
                pred_mask_coord_values_noise = self.head(dec_mask_tokens_noise)
        else:
            
            #dec_mask_tokens_noise = self.sample_to_original_size(dec_mask_tokens_noise)
            pred_mask_coord_values_noise = self.aux_head_2(dec_mask_tokens_noise) 
        pred_mask_coord_values_noise = pred_mask_coord_values_noise.view(B,N,-1,3)
        #pred_mask_coord_values_noise = pred_mask_coord_values_noise.view(B,N,-1,3)
        if self.add_residual: #true
            pred_mask_coord_values_noise += start

        if self.only_recons_past:
            loss_mask = 1 - mask_with_no_future
        else:
            #反掩码
            loss_mask = 1 - mask
        if self.virtual_joint:
            pred_future_coord_values = self.sample_to_original_size(pred_future_coord_values,original_size=self.n_agent)
            pred_mask_coord_values = self.sample_to_original_size(pred_mask_coord_values,original_size=self.n_agent)
            masked_gt = self.sample_to_original_size(masked_gt,original_size=self.n_agent)
            pred_mask_coord_values_noise = self.sample_to_original_size(pred_mask_coord_values_noise,original_size=self.n_agent)
            loss_mask = self.sample_to_original_size(loss_mask,original_size=self.n_agent)
        return pred_future_coord_values, pred_mask_coord_values,masked_gt, pred_mask_coord_values_noise, loss_mask,pred_future_coord_values_virtual,all_traj_virtual

    def mask_forward(self,all_trajs,mask,all_out=False):

        B,N,T = all_trajs.shape[0],all_trajs.shape[1],all_trajs.shape[2]
        
        if self.concat_acc:
            vel = torch.zeros_like(all_trajs)
            vel[:,:,1:] = all_trajs[:,:,1:] - all_trajs[:,:,:-1]
            acc = torch.zeros_like(vel)
            acc[:,:,1:] = vel[:,:,1:] - vel[:,:,:-1]
            all_traj_input = torch.cat([all_trajs,vel,acc],dim=-1)
        elif self.concat_vel:
            vel = torch.zeros_like(all_trajs)
            vel[:,:,1:] = all_trajs[:,:,1:] - all_trajs[:,:,:-1]
            all_traj_input = torch.cat([all_trajs,vel],dim=-1)
        else:
            all_traj_input = all_trajs#

        batch_ind = torch.arange(B)[:,None,None].cuda()
        agent_ind = torch.arange(N)[None,:,None].cuda()

        inverse_mask = 1 - mask
        unmask_tokens = self.patch_embed(all_traj_input) * mask[:,:,:,None] #12 25 20 64 
        #unmask_tokens = self.patch_embed(all_traj_input)
        unmask_tokens += self.pos_embed.repeat(B,N,1,1) # 12 25 20 64  

        if self.add_joint_token:

            unmask_tokens += self.agent_embed.repeat(B,1,T,1)


        unmask_tokens = unmask_tokens * mask[:,:,:,None] #广播

        mask_s = mask.permute(0,2,1).contiguous().view(B*T,N)    #torch.Size([240, 25]) 12*20
        mask_s = torch.matmul(mask_s[:,:,None],mask_s[:,None,:]) #torch.Size([240, 25, 25])
        mask_t = mask.contiguous().view(B*N,T)
        mask_t = torch.matmul(mask_t[:,:,None],mask_t[:,None,:])

        unmask_tokens_pad = unmask_tokens #torch.Size([12, 25, 20, 64])
        mask_ind = torch.arange(T)[None,None,:].repeat(B,N,1).cuda()#torch.Size([12, 25, 20])

        out = []

        
        for l in range(self.encoder_depth):
            if l == 0:
                encoded_tokens = self.encoder[l](unmask_tokens_pad,mask_s,mask_t) #torch.Size([12, 25, 20, 64])
                #得到编码tokens之后再加入掩码
                enc_to_dec_tokens = encoded_tokens * mask[:,:,:,None]
                #生成mask_tokens，用embedding嵌入信息
                mask_tokens = self.mask_embed[None, None, None,:].repeat(B,N,T,1) #torch.Size([12, 25, 20, 64])
                #再加位置信息？
                mask_tokens += self.decoder_pos_embed(mask_ind) #12 25 20 64

                if self.add_joint_token:
                    #加关节信息嵌入
                    mask_tokens += self.decoder_agent_embed(agent_ind.repeat(B,1,mask_tokens.shape[2]))
                
                #得到反掩码的tokens
                mask_tokens = mask_tokens * inverse_mask[:,:,:,None]
                #信息相加得到解码器输入
                concat_tokens = enc_to_dec_tokens + mask_tokens
                dec_input_tokens = concat_tokens

                if self.decoder_masking:
                    decoded_tokens = self.decoder[l](dec_input_tokens,1-mask_s,1-mask_t)
                else:
                    decoded_tokens = self.decoder[l](dec_input_tokens) #torch.Size([12, 25, 20, 64])
                out.append(decoded_tokens)
            else:
                #多层结构，下一层编码器的输入为上一层transformer解码器的输出
                encoder_input = decoded_tokens

                encoder_input_pad = encoder_input * mask[:,:,:,None]
                encoder_output = self.encoder[l](encoder_input_pad,mask_s,mask_t)

                decoded_tokens = encoder_output * mask[:,:,:,None] + decoded_tokens * inverse_mask[:,:,:,None]
                if self.decoder_masking:
                    decoded_tokens = self.decoder[l](decoded_tokens,1-mask_s,1-mask_t)
                else:
                    decoded_tokens = self.decoder[l](decoded_tokens)
                out.append(decoded_tokens)
        if self.multi_output and all_out:
            return out
        else:
            return decoded_tokens

    def predict(self,all_traj):
        all_traj = self.get_padding_traj(all_traj)
        B,N,T = all_traj.shape[0],all_traj.shape[1],all_traj.shape[2]
        # assert N == 1
        all_traj = all_traj.view(B,N,T,3)
        start = all_traj[:,:,self.past_timestep-1:self.past_timestep]
        vel = torch.zeros_like(all_traj)
        vel[:,:,1:] = all_traj[:,:,1:] - all_traj[:,:,:-1]
        all_traj_with_vel = torch.cat([all_traj,vel],dim=-1)

        past_future_indices = torch.arange(T)[None].repeat(B,1).cuda()
        past_future_indices = past_future_indices[:,None,:].repeat(1,N,1)
        past_ind, future_ind = past_future_indices[:,:, :self.past_timestep], past_future_indices[:,:, self.past_timestep:]

        batch_ind = torch.arange(B)[:,None,None].cuda()
        agent_ind = torch.arange(N)[None,:,None].cuda()

        ordinary_mask = torch.zeros((B,N,T)).type_as(all_traj)
        ordinary_mask[:,:,:self.past_timestep] = 1.

        if self.multi_output:
            decoded_tokens = self.mask_forward(all_traj,ordinary_mask,all_out=True)[-1]
        else:
            decoded_tokens = self.mask_forward(all_traj,ordinary_mask)

        dec_future_tokens = decoded_tokens[batch_ind,agent_ind, future_ind, :]

        if self.multi_output:
            pred_future_coord_values = self.head[-1](dec_future_tokens)
        else:
            #通过线行程转换为坐标的输出
            pred_future_coord_values = self.head(dec_future_tokens)

        pred_future_coord_values = pred_future_coord_values.view(B,N,-1,3)
        if self.add_residual:
            pred_future_coord_values += start
        pred_future_coord_values = self.sample_to_original_size(pred_future_coord_values)
        return pred_future_coord_values

    def predict_with_mask(self,all_traj,unmask_ind):
        all_traj = self.get_padding_traj(all_traj)
        B,N,T = all_traj.shape[0],all_traj.shape[1],all_traj.shape[2]
        # assert N == 1
        all_traj = all_traj.view(B,N,T,3)
        start = all_traj[:,:,self.past_timestep-1:self.past_timestep]
        vel = torch.zeros_like(all_traj)
        vel[:,:,1:] = all_traj[:,:,1:] - all_traj[:,:,:-1]
        all_traj_with_vel = torch.cat([all_traj,vel],dim=-1)

        past_future_indices = torch.arange(T)[None].repeat(B,1).cuda()
        past_future_indices = past_future_indices[:,None,:].repeat(1,N,1)
        past_ind, future_ind = past_future_indices[:,:, :self.past_timestep], past_future_indices[:,:, self.past_timestep:]

        batch_ind = torch.arange(B)[:,None,None].cuda()
        agent_ind = torch.arange(N)[None,:,None].cuda()

        ordinary_mask = torch.zeros((B,N,T)).type_as(all_traj)
        # ordinary_mask[:,:,:self.past_timestep] = 1.

        ordinary_mask[batch_ind,agent_ind,unmask_ind] = 1.

        if self.multi_output:
            decoded_tokens = self.mask_forward(all_traj,ordinary_mask,all_out=True)[-1]
        else:
            decoded_tokens = self.mask_forward(all_traj,ordinary_mask)

        dec_future_tokens = decoded_tokens[batch_ind,agent_ind, future_ind, :]

        if self.multi_output:
            pred_future_coord_values = self.head[-1](dec_future_tokens)
            # pred_future_coord_values = self.head(dec_future_tokens)
        else:
            pred_future_coord_values = self.head(dec_future_tokens)

        pred_future_coord_values = pred_future_coord_values.view(B,N,-1,3)
        if self.add_residual:
            pred_future_coord_values += start
        pred_future_coord_values = self.sample_to_original_size(pred_future_coord_values)
        return pred_future_coord_values

    def predict_with_noise_double(self,all_traj):
        all_traj = self.get_padding_traj(all_traj)
        B,N,T = all_traj.shape[0],all_traj.shape[1],all_traj.shape[2]
        # assert N == 1
        all_traj = all_traj.view(B,N,T,3)
        start = all_traj[:,:,self.past_timestep-1:self.past_timestep]
        # all_traj = all_traj - start
        vel = torch.zeros_like(all_traj)
        vel[:,:,1:] = all_traj[:,:,1:] - all_traj[:,:,:-1]
        all_traj_with_vel = torch.cat([all_traj,vel],dim=-1)

        past_future_indices = torch.arange(T)[None].repeat(B,1).cuda()
        past_future_indices = past_future_indices[:,None,:].repeat(1,N,1)
        past_ind, future_ind = past_future_indices[:,:, :self.past_timestep], past_future_indices[:,:, self.past_timestep:]

        batch_ind = torch.arange(B)[:,None,None].cuda()
        agent_ind = torch.arange(N)[None,:,None].cuda()

        ordinary_mask = torch.zeros((B,N,T)).type_as(all_traj)
        ordinary_mask[:,:,:self.past_timestep] = 1.

        if self.multi_output:
            decoded_tokens = self.mask_forward(all_traj,ordinary_mask,all_out=True)[-1]
        else:
            decoded_tokens = self.mask_forward(all_traj,ordinary_mask)

        dec_past_tokens = decoded_tokens[batch_ind,agent_ind, past_ind, :]

        pred_past_coord_values = self.aux_head_2(dec_past_tokens)

        pred_past_coord_values = pred_past_coord_values.view(B,N,-1,3)
        if self.add_residual:
            pred_past_coord_values += start

        ordinary_mask2 = torch.zeros((B,N,T)).type_as(all_traj)
        ordinary_mask2[:,:,:self.past_timestep] = 1.

        all_traj2 = torch.zeros_like(all_traj)
        all_traj2[:,:,:self.past_timestep] = pred_past_coord_values
        if self.multi_output:
            decoded_tokens = self.mask_forward(all_traj2,ordinary_mask2,all_out=True)[-1]
        else:
            decoded_tokens = self.mask_forward(all_traj2,ordinary_mask2)

        dec_future_tokens = decoded_tokens[batch_ind,agent_ind, future_ind, :]

        if self.multi_output:
            pred_future_coord_values = self.head[-1](dec_future_tokens)
            # pred_future_coord_values = self.head(dec_future_tokens)
        else:
            pred_future_coord_values = self.head(dec_future_tokens)

        pred_future_coord_values = pred_future_coord_values.view(B,N,-1,3)
        if self.add_residual:
            pred_future_coord_values += start
        pred_future_coord_values = self.sample_to_original_size(pred_future_coord_values)
        return pred_future_coord_values
    def get_padding_traj(self, original_tensor):
        B,N,T,D = original_tensor.shape
        new_num_joints = original_tensor.size(1) * 2 - 1
        neighbor_avg = (original_tensor[:, :-1, :, :] + original_tensor[:, 1:, :, :]) / 2

        padded_tensor = torch.empty(B, new_num_joints, T, D).to('cuda')

        padded_tensor[:, ::2, :, :] = original_tensor
        padded_tensor[:, 1::2, :, :] = neighbor_avg
        del original_tensor
        del neighbor_avg
        return padded_tensor

    def sample_to_original_size(self, padded_tensor, original_size = 25):
        original_num_joints = original_size
        if padded_tensor.dim() == 4:
            sampled_tensor = padded_tensor[:, :original_num_joints*2-1:2, :, :]
        else:
            sampled_tensor = padded_tensor[:, :original_num_joints*2-1:2, :]
        return sampled_tensor
    def get_padding_traj2(self, original_tensor):
        B,N,T,D = original_tensor.shape
        new_num_joints = original_tensor.size(1) * 3//2
        padded_tensor =torch.randn(B, new_num_joints, T, D).to('cuda')

        for i in range(N):
            padded_tensor[:, i*3//2, :, :] = original_tensor[:, i, :, :]
        del original_tensor
        return padded_tensor
    def sample_to_original_size2(self, padded_tensor, original_size = 25):

        B = padded_tensor.shape[0]
        T = padded_tensor.shape[2]
        mask = torch.ones(padded_tensor.size(), dtype=torch.bool).to('cuda')
        mask[:, 2::3] = False
        sampled_tensor = torch.masked_select(padded_tensor, mask)
        if padded_tensor.dim() == 4:
            sampled_tensor = sampled_tensor.view(B, -1, T, padded_tensor.shape[3])
        else:
            B,N,T = padded_tensor.shape
            sampled_tensor = sampled_tensor.view(B,-1,T)
        return sampled_tensor
    def sample_to_virtual(self,padded_tensor):
        B = padded_tensor.shape[0]
        T = padded_tensor.shape[2]
        sampled_tensor = padded_tensor[:, 2::3]
        if padded_tensor.dim() == 4:
            sampled_tensor = sampled_tensor.view(B, -1, T, padded_tensor.shape[3])
        else:
            sampled_tensor = sampled_tensor.view(B,-1,T)
        return sampled_tensor 



class TrajTrans_spatial(nn.Module):
    def __init__(
        self, num_patches, h_dim, depth=3, num_heads=8, mlp_dim=128,
        pool='cls', dim_per_head=64, dropout=0., embed_dropout=0.
    ):
        super().__init__()
        
        patch_dim = 3
        self.patch_embed = nn.Linear(patch_dim, h_dim)

        self.pos_embed = nn.Parameter(torch.randn(1, num_patches, h_dim)).cuda()

        self.dropout = nn.Dropout(p=embed_dropout)
        
        self.transformer_s = Transformer(
            h_dim, h_dim*2, depth=depth, num_heads=num_heads,
            dim_per_head=dim_per_head, dropout=dropout
        )

        self.transformer_t = Transformer(
            h_dim, h_dim*2, depth=depth, num_heads=num_heads,
            dim_per_head=dim_per_head, dropout=dropout
        )

        self.pool = pool
    def forward(self, patches):
        B, M, C = patches.shape

        '''ii. Patch embedding'''
        # (b,n_patches,dim)
        tokens = self.patch_embed(patches)
        # (b,n_patches+1,dim)
        tokens = torch.cat([self.cls_token.repeat(b, 1, 1), tokens], dim=1)
        tokens += self.pos_embed[:, :(num_patches + 1)]
        tokens = self.dropout(tokens)

        '''iii. Transformer Encoding'''
        enc_tokens = self.transformer(tokens)

        '''iv. Pooling'''
        # (b,dim)
        pooled = enc_tokens[:, 0] if self.pool == 'cls' else enc_tokens.mean(dim=1)

        '''v. Classification'''
        # (b,n_classes)
        logits = self.mlp_head(pooled)

        return logits

#构建时间空间Transformer
class STTrans(nn.Module):
    def __init__(
        self, num_patches, h_dim, n_agent = 49, depth=3, num_heads=8, mlp_dim=128,
        pool='cls', dim_per_head=64, dropout=0., embed_dropout=0., multi_output=False,
        input_size = 64, hidden_size = 64,embed_size = 64
    ):
        super().__init__()

        self.dropout = nn.Dropout(p=embed_dropout)
        self.multi_output = multi_output
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.transformer_s = [] 
        self.transformer_t = []  
        self.depth = depth
        for i in range(depth):
            
            self.transformer_t.append(Transformer(
                h_dim, mlp_dim, n_agent=n_agent,depth=1, num_heads=num_heads,
                dim_per_head=dim_per_head, dropout=dropout,
                input_size = input_size, hidden_size = hidden_size,embed_size = embed_size
            ))
            self.transformer_s.append(Transformer(
                h_dim, mlp_dim, n_agent=n_agent,depth=1, num_heads=num_heads,
                dim_per_head=dim_per_head, dropout=dropout,
                input_size = input_size, hidden_size = hidden_size,embed_size = embed_size
            ))
        self.transformer_t = nn.ModuleList(self.transformer_t)
        self.transformer_s = nn.ModuleList(self.transformer_s)
        self.pool = pool

    def forward(self, x, mask_s=None, mask_t=None):
        B,N = x.shape[0], x.shape[1] #
        out = []
        for i in range(self.depth):
            x = x.contiguous().view(B*N,-1,x.shape[-1]) #300 20 64
            x = self.transformer_t[i](x,mask_t)
            x = x.view(B,N,-1,x.shape[-1]).permute(0,2,1,3)
            x = x.contiguous().view(-1,N,x.shape[-1]) #240 25 64
            x = self.transformer_s[i](x,mask_s)
            x = x.view(B,-1,N,x.shape[-1]).permute(0,2,1,3)
            out.append(x)
        if self.multi_output:
            return out
        else:
            return x

class TrajTrans(nn.Module):
    def __init__(
        self, num_patches, h_dim, depth=3, num_heads=8, mlp_dim=128,
        pool='cls', dim_per_head=64, dropout=0., embed_dropout=0.
    ):
        super().__init__()
        
        patch_dim = 3
        self.patch_embed = nn.Linear(patch_dim, h_dim)


        self.pos_embed = nn.Parameter(torch.randn(1, num_patches, h_dim)).cuda()

        self.dropout = nn.Dropout(p=embed_dropout)

        self.transformer = Transformer(
            h_dim, h_dim*2, depth=depth, num_heads=num_heads,
            dim_per_head=dim_per_head, dropout=dropout
        )

        self.pool = pool
    def forward(self, patches):
        B, M, C = patches.shape

        '''ii. Patch embedding'''
        # (b,n_patches,dim)
        tokens = self.patch_embed(patches)
        # (b,n_patches+1,dim)
        tokens = torch.cat([self.cls_token.repeat(b, 1, 1), tokens], dim=1)
        tokens += self.pos_embed[:, :(num_patches + 1)]
        tokens = self.dropout(tokens)

        '''iii. Transformer Encoding'''
        enc_tokens = self.transformer(tokens)

        '''iv. Pooling'''
        # (b,dim)
        pooled = enc_tokens[:, 0] if self.pool == 'cls' else enc_tokens.mean(dim=1)

        '''v. Classification'''
        # (b,n_classes)
        logits = self.mlp_head(pooled)

        return logits

def to_pair(t):
    return t if isinstance(t, tuple) else (t, t)

class PreNorm(nn.Module):
    def __init__(self, dim, net):
        super().__init__()

        self.norm = nn.LayerNorm(dim)
        self.net = net
    
    def forward(self, x, **kwargs):
        #return self.net(self.norm(x), **kwargs)
        return self.net(self.norm(x), **kwargs)


    
#注意力机制
class SelfAttention(nn.Module):
    def __init__(self, dim, n_agent = 49, num_heads=8, dim_per_head=64, dropout=0.,input_size = 64, hidden_size = 64):
        super().__init__()
        dropout = 0.
        self.n_agent = n_agent*2-1
        self.num_heads = num_heads
        self.scale = dim_per_head ** -0.5 

        inner_dim = dim_per_head * num_heads#
        self.GCN = GC_Block(inner_dim, n_agents=self.n_agents)
        self.to_qkv = nn.Linear(dim, inner_dim * 3, bias=False) 
        self.attend = nn.Softmax(dim=-1) 

        project_out = not (num_heads == 1 and dim_per_head == dim)
        self.out = nn.Sequential(
            nn.Linear(inner_dim, dim),
            nn.Dropout(dropout)
        ) if project_out else nn.Identity()
    
    def forward(self, x, mask=None):
        
        if x.shape[1] == self.n_agent:
            x= self.GCN(x)
        b, l, d = x.shape #480 25 64  600,20,64
        '''i. QKV projection'''
        # (b,l,dim_all_heads x 3)
        qkv = self.to_qkv(x)

        # (3,b,num_heads,l,dim_per_head)
        qkv = qkv.view(b, l, 3, self.num_heads, -1).permute(2, 0, 3, 1, 4).contiguous()#num_heads->8,b->300,l->20
        q, k, v = qkv.chunk(3)
        q, k, v = q.squeeze(0), k.squeeze(0), v.squeeze(0) #480 8 25 32
        '''ii. Attention computation'''
        #
        attn = self.attend(torch.matmul(q, k.transpose(-1, -2)) * self.scale)
        if mask is not None:
            mask = mask[:,None,:,:].repeat(1,self.num_heads,1,1)  
            attn = attn * mask                                     
            attn = attn / (torch.sum(attn,dim=-1,keepdim=True)+1e-10)

        '''iii. Put attention on Value & reshape'''

        z = torch.matmul(attn, v)       
        z = z.transpose(1, 2).reshape(b, l, -1)
        # assert z.size(-1) == q.size(-1) * self.num_heads
        '''iv. Project out'''
        # (b,l,dim_all_heads)->(b,l,dim)
        out = self.out(z)

        return out #torch.Size([300, 20, 64])

class GraphConvolution(nn.Module):
    """
    adapted from : https://github.com/tkipf/gcn/blob/92600c39797c2bfb61a508e52b88fb554df30177/gcn/layers.py#L132
    """
    def __init__(self, in_features, out_features, bias=True, node_n=49):
        super(GraphConvolution, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.weight = Parameter(torch.FloatTensor(in_features, out_features))
        self.att = Parameter(torch.FloatTensor(node_n, node_n))
        if bias:
            self.bias = Parameter(torch.FloatTensor(out_features))
        else:
            self.register_parameter('bias', None)
        self.reset_parameters()

    def reset_parameters(self):
        stdv = 1. / math.sqrt(self.weight.size(1))
        self.weight.data.uniform_(-stdv, stdv)
        self.att.data.uniform_(-stdv, stdv)
        if self.bias is not None:
            self.bias.data.uniform_(-stdv, stdv)

    def forward(self, input):
        support = torch.matmul(input, self.weight)
        output = torch.matmul(self.att, support)
        if self.bias is not None:
            return output + self.bias
        else:
            return output

    def __repr__(self):
        return self.__class__.__name__ + ' (' \
               + str(self.in_features) + ' -> ' \
               + str(self.out_features) + ')'


#######################################
class GC_Block(nn.Module):
    def __init__(self, in_features, p_dropout=0.3, bias=True, node_n=49):
        """
        Define a residual block of GCN
        """
        super(GC_Block, self).__init__()
        self.in_features = in_features
        self.out_features = in_features
        self.gc1 = GraphConvolution(in_features, in_features, node_n=node_n, bias=bias)
        self.bn1 = nn.BatchNorm1d(node_n * in_features)
        #self.ln1 = nn.LayerNorm(in_features)
        self.gc2 = GraphConvolution(in_features, in_features, node_n=node_n, bias=bias)
        self.bn2 = nn.BatchNorm1d(node_n * in_features)

        self.do = nn.Dropout(p=0.)
        self.act_f = nn.Tanh()

    def forward(self, x):
        y = self.gc1(x)
        #batch,node,frame
        b, n, f = y.shape 
        y = self.bn1(y.view(b, -1)).view(b, n, f)
        #y = self.ln1(y)
        y = self.act_f(y)
        y = self.do(y)

        y = self.gc2(y)
        b, n, f = y.shape
        y = self.bn2(y.view(b, -1)).view(b, n, f)
        #y = self.ln2(y)
        y = self.act_f(y)
        y = self.do(y)

        return y+x

    def __repr__(self):
        return self.__class__.__name__ + ' (' \
               + str(self.in_features) + ' -> ' \
               + str(self.out_features) + ')'


class FFN(nn.Module):
    def __init__(self, dim, hidden_dim, dropout=0.):
        super().__init__()
        #改过
        dropout = 0.
        self.net = nn.Sequential(
            nn.Linear(dim, hidden_dim),
            nn.GELU(),
            #SwiGLU(hidden_dim,hidden_dim),
            nn.Dropout(p=dropout),
            nn.Linear(hidden_dim, dim),
            nn.Dropout(p=0)
            #nn.Dropout(p=dropout)
        )
    def forward(self, x):
        return self.net(x)


class Transformer(nn.Module):
    def __init__(self, dim, mlp_dim, input_size, hidden_size,embed_size,n_agent = 49,
                 depth=1, num_heads=8, dim_per_head=64, dropout=0.,
                 ):
        super().__init__()

        self.layers = nn.ModuleList([])
        for _ in range(depth):
            self.layers.append(nn.ModuleList([
                PreNorm(dim, SelfAttention(dim, num_heads=num_heads, n_agent=n_agent,dim_per_head=dim_per_head, dropout=dropout)),
                PreNorm(dim, FFN(dim, mlp_dim, dropout=dropout))
            ]))
    
    def forward(self, x, mask=None):
        for norm_attn, norm_ffn in self.layers:
            x = x + norm_attn(x,mask=mask)
            x = x + norm_ffn(x)
        return x



class MLP(nn.Module):
    def __init__(self, input_dim, output_dim, hidden_size=(1024, 512), activation='relu', discrim=False, dropout=-1):
        super(MLP, self).__init__()
        dims = []
        dims.append(input_dim)
        dims.extend(hidden_size)
        dims.append(output_dim)
        self.layers = nn.ModuleList()
        for i in range(len(dims)-1):
            self.layers.append(nn.Linear(dims[i], dims[i+1]))

        if activation == 'relu':
            self.activation = nn.ReLU()
        elif activation == 'sigmoid':
            self.activation = nn.Sigmoid()

        self.sigmoid = nn.Sigmoid() if discrim else None
        self.dropout = dropout

    def forward(self, x):
        for i in range(len(self.layers)):
            x = self.layers[i](x)
            if i != len(self.layers)-1:
                x = self.activation(x)
                if self.dropout != -1:
                    x = nn.Dropout(min(0.1, self.dropout/3) if i == 1 else self.dropout)(x)
            elif self.sigmoid:
                x = self.sigmoid(x)
        return x

