import argparse
import torch
from dataset.dataloader import H36motion3D
from model.model import SEFormer
from mpl_toolkits.mplot3d import Axes3D
from torch import nn, optim
import matplotlib.animation as animation
import json
import time
import numpy as np
import matplotlib.pyplot as plt
import math
import random
import yaml
import os

def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True

def lr_decay(optimizer, lr_now, gamma):
    lr_new = lr_now * gamma
    for param_group in optimizer.param_groups:
        param_group['lr'] = lr_new
    return lr_new

def create_pose(ax,plots,vals,index=0,pred=True,update=False):

    # h36m 32 joints(full)
    connect = [
            (1, 2), (2, 3), (3, 4), (4, 5),
            (6, 7), (7, 8), (8, 9), (9, 10),
            (0, 1), (0, 6),
            (6, 17), (17, 18), (18, 19), (19, 20), (20, 21), (21, 22),
            (1, 25), (25, 26), (26, 27), (27, 28), (28, 29), (29, 30),
            (24, 25), (24, 17),
            (24, 14), (14, 15)
    ]
    LR = [
            False, True, True, True, True,
            True, False, False, False, False,
            False, True, True, True, True,
            True, True, False, False, False,
            False, False, False, False, True,
            False, True, True, True, True,
            True, True
    ]  


# Start and endpoints of our representation
    I   = np.array([touple[0] for touple in connect])
    J   = np.array([touple[1] for touple in connect])
# Left / right indicator
    LR  = np.array([LR[a] or LR[b] for a,b in connect])
    if pred:
        lcolor = "#9b59b6"
        rcolor = "#2ecc71"
        if index <2:
            lcolor = "#8e8e8e"
            rcolor = "#383838"

    else:
        lcolor = "#8e8e8e"
        rcolor = "#383838"

    for i in np.arange( len(I) ):
        x = np.array( [vals[I[i], 0], vals[J[i], 0]] )
        z = np.array( [vals[I[i], 1], vals[J[i], 1]] )
        y = np.array( [vals[I[i], 2], vals[J[i], 2]] )
        if not update:

            if i ==0:
                plots.append(ax.plot(x, y, z, lw=2,linestyle='-' ,c=lcolor if LR[i] else rcolor,label=['GT' if not pred else 'Pred']))
            else:
                plots.append(ax.plot(x, y, z, lw=2,linestyle='-', c=lcolor if LR[i] else rcolor))

        elif update:
            plots[i][0].set_xdata(x)
            plots[i][0].set_ydata(y)
            plots[i][0].set_3d_properties(z)
            plots[i][0].set_color(lcolor if LR[i] else rcolor)
    
    return plots
   # ax.legend(loc='lower left')


# In[11]:


def update(num,data_gt,data_pred,plots_gt,plots_pred,fig,ax):
    
    gt_vals=data_gt[num]
    pred_vals=data_pred[num]
    plots_gt=create_pose(ax,plots_gt,gt_vals,pred=False,update=True)
    plots_pred=create_pose(ax,plots_pred,pred_vals,pred=True,update=True)

    r = 0.75
    xroot, zroot, yroot = gt_vals[0,0], gt_vals[0,1], gt_vals[0,2]
    ax.set_xlim3d([-r+xroot, r+xroot])
    ax.set_ylim3d([-r+yroot, r+yroot])
    ax.set_zlim3d([-r+zroot, r+zroot])
    #ax.set_title('pose at time frame: '+str(num))
    #ax.set_aspect('equal')
 
    return plots_gt,plots_pred
    



def main():
    if args.seed >= 0:
        seed = args.seed
        setup_seed(seed)
    else:
        seed = random.randint(0,1000)
        setup_seed(seed)
    print('The seed is :',seed)

    past_length = args.past_length
    future_length = args.future_length

    acts = ["walking", "eating", "smoking", "discussion", "directions",
            "greeting", "phoning", "posing", "purchases", "sitting",
            "sittingdown", "takingphoto", "waiting", "walkingdog",
            "walkingtogether"]

    loaders_test = {}
    viz_act = "takingphoto"
    for act in acts:
        if act == viz_act:
            dataset_test = H36motion3D(actions=act, input_n=args.past_length, output_n=args.future_length, split=1, scale=args.scale)
            loaders_test[act] = torch.utils.data.DataLoader(dataset_test, batch_size=1, shuffle=False, drop_last=False,
                                                    num_workers=0)

    dim_used = dataset_test.dim_used

    model = SEFormer(in_dim=2, 
                    h_dim=args.nf, 
                    past_timestep=args.past_length,
                    future_timestep=args.future_length, 
                    mask_ratio=args.mask_ratio, 
                    decoder_dim=args.decoder_dim, 
                    num_heads=8, 
                    encoder_depth=args.encoder_depth,
                    decoder_depth=args.decoder_depth,
                    decoder_dim_per_head=args.dim_per_head,
                    same_head=args.same_head,
                    range_mask_ratio=args.range_mask_ratio,
                    mlp_head=args.mlp_head,
                    mask_past=args.mask_past,
                    mask_range=args.mask_range,
                    multi_output=args.multi_output,
                    decoder_masking=args.decoder_masking,
                    pred_all=args.pred_all,
                    mlp_dim=args.mlp_dim,
                    dim_per_head=args.dim_per_head,
                    noise_dev=args.noise_dev,
                    part_noise=args.part_noise,
                    denoise_mode=args.denoise_mode,
                    part_noise_ratio=args.part_noise_ratio,
                    add_joint_token=args.add_joint_token,
                    n_agent=22,
                    concat_vel=args.concat_vel,
                    only_recons_past=args.only_recons_past,
                    add_residual=args.add_residual,
                    denoise=args.denoise,
                    regular_masking=args.regular_masking,
                    multi_same_head=args.multi_same_head,
                    range_noise_dev=args.range_noise_dev
    )

    model = model.cuda()

    # def get_parameter_number(model):
    #     total_num = sum(p.numel() for p in model.parameters())
    #     trainable_num = sum(p.numel() for p in model.parameters() if p.requires_grad)
    #     return {'Total': total_num, 'Trainable': trainable_num}
    # print(get_parameter_number(model))

    optimizer = optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    
    model_path = args.model_save_dir + '/' + args.model_save_name +'.pth.tar'
    print('Loading model from:', model_path)
    model_ckpt = torch.load(model_path)
    model.load_state_dict(model_ckpt['state_dict'])
    model.eval()

    if args.future_length == 25 or args.future_length == 13:
        avg_mpjpe = np.zeros((6))
    elif args.future_length == 15:
        avg_mpjpe = np.zeros((2))
    else:
        avg_mpjpe = np.zeros((4))
    for act in acts:
        if act==viz_act:
            print("now is:"+act)
            test(model, optimizer, 0, (act, loaders_test[act]), dim_used, backprop=False)
        # save_errors(model, optimizer, 0, (act, loaders_test[act]), dim_used, backprop=False
    return



def test(model, optimizer, epoch, act_loader,dim_used=[],backprop=False):
    dim_used = np.array([6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 21, 22, 23, 24, 25,
                    26, 27, 28, 29, 30, 31, 32, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45,
                    46, 47, 51, 52, 53, 54, 55, 56, 57, 58, 59, 63, 64, 65, 66, 67, 68,
                    75, 76, 77, 78, 79, 80, 81, 82, 83, 87, 88, 89, 90, 91, 92])    
    act, loader = act_loader[0], act_loader[1]

    model.eval()

    validate_reasoning = False
    if validate_reasoning:
        acc_list = [0]*args.n_layers
    res = {'epoch': epoch, 'loss': 0, 'counter': 0}

    output_n = args.future_length
    if output_n == 25:
        eval_frame = [1, 3, 7, 9, 13, 24]
    elif output_n == 15:
        eval_frame = [3, 14]
    elif output_n == 10:
        eval_frame = [1, 3, 7, 9]
    elif output_n == 13:
        eval_frame = [0,1,3,4,6,12]
    t_3d = np.zeros(len(eval_frame))

    with torch.no_grad():
        for batch_idx, data in enumerate(loader):
            batch_size, n_nodes, length, _ = data[0].size() #torch.Size([1, 22, 10, 3])
            data = [d.to(device) for d in data]
            loc, vel, loc_end, loc_end_ori, _ = data #torch.Size([1, 22, 10, 3]),_,torch.Size([1, 22, 10, 3]),torch.Size([1, 10, 96])

            loc_start = loc[:,:,-1:]
            pred_length = loc_end.shape[2]

            optimizer.zero_grad()

            loc_end_fake = torch.zeros_like(loc_end)
            all_traj = torch.cat([loc,loc_end_fake],dim=2)
            loc_pred = model.predict(all_traj) #(B,N,T,3)

            pred_3d = loc_end_ori.clone()
            loc_pred = loc_pred.transpose(1,2)
            loc_pred = loc_pred.contiguous().view(batch_size,loc_end.shape[2],n_nodes*3)#1,10,66
            
            joint_to_ignore = np.array([16, 20, 23, 24, 28, 31])
            index_to_ignore = np.concatenate((joint_to_ignore * 3, joint_to_ignore * 3 + 1, joint_to_ignore * 3 + 2))
            joint_equal = np.array([13, 19, 22, 13, 27, 30])
            index_to_equal = np.concatenate((joint_equal * 3, joint_equal * 3 + 1, joint_equal * 3 + 2))

            pred_3d[:,:,dim_used] = loc_pred
            pred_3d[:, :, index_to_ignore] = pred_3d[:, :, index_to_equal]
            pred_p3d = pred_3d.contiguous().view(batch_size, pred_length, -1, 3) #[:, input_n:, :, :]
            targ_p3d = loc_end_ori.contiguous().view(batch_size, pred_length, -1, 3) #[:, input_n:, :, :]

            all_joints_seq = pred_3d
            all_joints_seq=all_joints_seq.view(-1,output_n,32,3)
            sequences_gt = targ_p3d
            sequences_gt=sequences_gt.view(-1,output_n,32,3)
            sequences_past = loc[:, :,-4:, :]
            print(sequences_past.shape)
            #sequences_past=sequences_past.view(-1,4,32,3)
            
            #loss=mpjpe_error(all_joints_seq,sequences_gt)# # both must have format (batch,T,V,C)
            
            data_pred=torch.squeeze(all_joints_seq,0).cpu().data.numpy()/10 # in meters
            data_gt=torch.squeeze(sequences_gt,0).cpu().data.numpy()/10
            #data_past = torch.squeeze(sequences_past,0).cpu().data.numpy()/1000
    
            fig = plt.figure()
            ax = Axes3D(fig)
            ax.view_init(elev=20, azim=-40)
            vals = np.zeros((32, 3)) # or joints_to_consider
            gt_plots=[]
            pred_plots=[]
    
            gt_plots=create_pose(ax,gt_plots,vals,pred=False,update=False)
            pred_plots=create_pose(ax,pred_plots,vals,pred=True,update=False)
            # ax.set_axis_off()
            # ax.grid(False)
            ax.set_xlabel("x")
            ax.set_ylabel("y")
            ax.set_zlabel("z")
            ax.legend(loc='lower left')
    
            ax.set_xlim3d([-1, 1.5])
            ax.set_xlabel('X')
    
            ax.set_ylim3d([-1, 1.5])
            ax.set_ylabel('Y')
    
            ax.set_zlim3d([0.0, 1.5])
            ax.set_zlabel('Z')
            #ax.set_title('loss in mm is: '+str(round(loss.item(),4))+' for action : '+str(action)+' for '+str(output_n)+' frames')
    
            line_anim = animation.FuncAnimation(fig, update, output_n, fargs=(data_gt,data_pred,gt_plots,pred_plots,
                                                                       fig,ax),interval=70, blit=False)
            plt.show()
            
            line_anim.save('human_viz.gif',writer='pillow')


            fig, ax_list = plt.subplots(1, output_n, subplot_kw={'projection': '3d'},figsize=(64, 48),gridspec_kw={'hspace':-0.5,'wspace':-0.93})
            print(output_n)
            for ax in ax_list:
                ax.view_init(elev=20, azim=-40)
                ax.set_axis_off()
                ax.grid(False)   
                    # 设置坐标轴范围，使动作更清晰
                ax.set_xlim3d([-0.7, 0.7])
                ax.set_ylim3d([-0.7, 0.7])
                ax.set_zlim3d([0.0, 1.4])
            for i, num in enumerate(range(0, output_n, 1)):

                gt_vals = data_gt[num]
                pred_vals = data_pred[num]
                #create_pose(ax_list[i], [], gt_vals, pred=False, update=False)
                create_pose(ax_list[i], [], pred_vals,index=10,pred=True, update=False)

            #plt.subplots_adjust(wspace=-0.2, hspace=-0.2)
            plt.gcf().set_size_inches(80, 4)
            # 保存图像到文件
            plt.show()
            plt.savefig('multi_frame_plot_'+str(act)+str(batch_idx)+'.png')
    return 0

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='VAE MNIST Example')
    parser.add_argument('--no-cuda', action='store_true', default=False, help='enables CUDA training')
    parser.add_argument('--seed', type=int, default=-1, metavar='S', help='random seed (default: -1)')
    parser.add_argument("--debug",action='store_true')
    parser.add_argument('--model_save_dir', type=str, default='ckpt3', help='dir to save model')
    parser.add_argument("--model_save_name",type=str,default="default")
    parser.add_argument("--task",type=str,default="short")
    args = parser.parse_args()

    if args.task == 'short':
        with open('cfg/h36m_short.yml', 'r') as f:
            yml_arg = yaml.safe_load(f)
    else:
        with open('cfg/h36m_long.yml', 'r') as f:
            yml_arg = yaml.safe_load(f)

    parser.set_defaults(**yml_arg)
    args = parser.parse_args()
    args.cuda = True

    device = torch.device("cuda" if args.cuda else "cpu")

    print(args)
    main()




